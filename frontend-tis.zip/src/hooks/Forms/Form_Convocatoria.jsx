import { useState } from "react";
import PropTypes from "prop-types";
import {
  FormControl,
  TextField,
  CssBaseline,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";

import { Box, Button } from "@mui/material";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { LocalizationProvider } from "@mui/x-date-pickers-pro";
import { AdapterDayjs } from "@mui/x-date-pickers-pro/AdapterDayjs";
import { DateRangePicker } from "@mui/x-date-pickers-pro/DateRangePicker";
import { postConv } from "../../api/api";

const Form_Convocatoria = ({ onClose, edit }) => {
  const [formData, setFormData] = useState({
    name: "",
    dateB: null,
    dateE: null,
    facultad: "",
    carrera: "",
    tipo: "",
  });

  const [carreras, setCarreras] = useState([]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFacultadChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });

    if (value === "Facultad de veterinaria") {
      setCarreras(["Veterinaria"]);
    } else if (value === "Facultad de Ciencias y Tecnologia") {
      setCarreras([
        "Ing. Sistemas",
        "Ing. Electronica",
        "Ing. Eletrica",
        "Ing. Civil",
        "Ing. Industrial",
      ]);
    } else {
      setCarreras([]);
    }
  };

  const handleDateRangeChange = (newDateRange) => {
    setFormData({
      ...formData,
      dateB: newDateRange[0],
      dateE: newDateRange[1],
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Tu lógica de manejo de envío de datos aquí
      const dataToSend = {
        name: formData.name,
        dateB: formData.dateB,
        dateE: formData.dateE,
        facultad: formData.facultad,
        carrera: formData.carrera,
        tipo: formData.tipo,
      };
      // Convert the dataToSend object to a JSON string
      const jsonData = JSON.stringify(dataToSend);

      // Send a POST request with JSON data
      const response = await postConv("http://localhost:8000/api/v1/registerconv", jsonData);

      // Check the response status
      if (response.status === 200) {
        // The request was successful
        console.log("Datos enviados con éxito");
      } else {
        console.error("Error en la solicitud a la API");
      }

      onClose();
    } catch (error) {
      console.error("Error sending data to API:", error);
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        height: "80vh",
      }}
    >
      <CssBaseline />

      <form onSubmit={handleSubmit}>
        <FormControl
          sx={{
            width: 320,
            flexGrow: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
          }}
        >
          <Box sx={{ mt: 0 }}>
            <TextField
              required
              label="Nombre Encargado"
              variant="outlined"
              fullWidth
              name="name"
              value={formData.name}
              onChange={handleChange}
              margin="dense"
            />
          </Box>
          <Box>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DemoContainer components={["DateRangePicker"]}>
                <DateRangePicker
                  localeText={{ start: "Fecha inicio", end: "Fecha fin" }}
                  onChange={handleDateRangeChange} // Agrega este evento
                />
              </DemoContainer>
            </LocalizationProvider>
          </Box>

          <Box sx={{ mt: 2, marginBottom: 2 }}>
            <FormControl fullWidth variant="outlined">
              <InputLabel htmlFor="facultad">Facultad</InputLabel>
              <Select
                required
                label="Facultad"
                name="facultad"
                value={formData.facultad}
                onChange={handleFacultadChange}
                inputProps={{
                  name: "facultad",
                  id: "facultad",
                }}
              >
                <MenuItem value="Facultad de veterinaria">
                  Facultad de veterinaria
                </MenuItem>
                <MenuItem value="Facultad de Ciencias y Tecnologia">
                  Facultad de Ciencias y tecnologia
                </MenuItem>
              </Select>
            </FormControl>
          </Box>

          <Box sx={{ mt: 2, marginBottom: 2 }}>
            <FormControl fullWidth variant="outlined">
              <InputLabel htmlFor="carrera">Carrera</InputLabel>
              <Select
                required
                label="Carrera"
                name="carrera"
                value={formData.carrera}
                onChange={(e) => {
                  setFormData({
                    ...formData,
                    carrera: e.target.value,
                  });
                }}
                inputProps={{
                  name: "carrera",
                  id: "carrera",
                }}
              >
                {carreras.map((carrera, index) => (
                  <MenuItem key={index} value={carrera}>
                    {carrera}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Box>
        </FormControl>

        <Box sx={{ mt: 2 }}>
          <FormControl fullWidth variant="outlined">
            <InputLabel htmlFor="tipo_eleccion">Tipo de eleccion</InputLabel>
            <Select
              required
              label="tipo de eleccion"
              name="tipo"
              value={formData.tipo}
              onChange={handleChange}
              inputProps={{
                name: "tipo",
                id: "tipo",
              }}
            >
              <MenuItem value="Rector">Rector</MenuItem>
              <MenuItem value="Decano">Decano</MenuItem>
              <MenuItem value="HCF">HCF</MenuItem>
              <MenuItem value="HCU">HCU</MenuItem>
            </Select>
          </FormControl>
        </Box>

        <Box sx={{ mt: 2 }}>
          <Button
            type="submit"
            sx={{
              width: "100%",
              borderRadius: "55px",
              boxShadow: "2px 2px 5px rgba(0, 0, 0, 0.9)",
            }}
            variant="solid"
            color="primary"
          >
            {edit ? "Editar Convocatoria" : "Crear Convocatoria"}
          </Button>
        </Box>
      </form>
    </Box>
  );
};

export default Form_Convocatoria;

Form_Convocatoria.propTypes = {
  onClose: PropTypes.func.isRequired,
  selectedProduct: PropTypes.object,
  edit: PropTypes.bool.isRequired,
  getProduct: PropTypes.func.isRequired,
};
