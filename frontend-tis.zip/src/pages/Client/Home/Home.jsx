// import React from "react";

import Client from "../../../components/layout/client/Client";

export default function Home() {
  return (
    <Client>
      Hola <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
      <div>as</div>
    </Client>
  );
}
