import "./App.css";
import { AppRouter } from "./routes/AppRouter";
// import React from "react";
const App = () => {
  
  return (
    <div>
      <AppRouter /> {/* Asegúrate de que estás utilizando el nombre correcto */}
    </div>
  );
};

export default App;
