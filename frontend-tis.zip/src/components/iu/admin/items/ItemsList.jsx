export const item1 = ["Productos", "Ventas", "Compras"];
